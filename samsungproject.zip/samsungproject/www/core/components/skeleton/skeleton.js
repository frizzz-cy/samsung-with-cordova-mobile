export default {
  name: 'skeleton'
};